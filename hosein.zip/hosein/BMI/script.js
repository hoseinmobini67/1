var heightInput = document.querySelector(".height-input-field");
var weightInput = document.querySelector(".weight-input-field");
var calculateButton = document.querySelector(".calculate");
var result = document.querySelector(".result");
var statement = document.querySelector(".result-statement");
var BMI, height, weight;

calculateButton.addEventListener("click", ()=>{
    
    height = heightInput.value;
    weight = weightInput.value;
    BMI = weight/(height**2); 
    result.innerText = BMI;

    if(BMI < 18.5){
        statement.innerText = "بی ام آی شما بسیار پایین است";    
    }else if((BMI > 18.5) && (BMI < 24.9)){
        statement.innerText = "حالت طبیعی می باشد";
    }else if((BMI > 25) && (BMI < 29.9 )){
        statement.innerText = "اضافه تر از حد معمول و نسبی می باشد";
    }else{
        statement.innerText = "اضافه تر از حد معمول و بسیار زیاد";
    }
});
